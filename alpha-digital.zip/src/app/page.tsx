/**
 * Home Page
 * Main landing page with all sections
 */

import Hero from '@/components/sections/Hero';
import Process from '@/components/sections/Process';
import CaseHero from '@/components/sections/CaseHero';
import ResultsGrid from '@/components/sections/ResultsGrid';
import FAQ from '@/components/sections/FAQ';
import CTAFinal from '@/components/sections/CTAFinal';
import Footer from '@/components/sections/Footer';
import Header from '@/components/sections/Header';
import ScrollProgress from '@/components/ui/ScrollProgress';

/**
 * Home Page Component
 * Server Component by default in App Router
 */
export default function HomePage() {
  return (
    <>
      {/* Fixed Header */}
      <Header />
      
      {/* Scroll Progress Bar */}
      <ScrollProgress />
      
      {/* Main Sections */}
      <Hero />
      <Process />
      <CaseHero />
      <ResultsGrid />
      <FAQ />
      <CTAFinal />
      <Footer />
    </>
  );
}
