/**
 * Contact Form API Route
 * Handles form submissions and saves to database
 */

import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { leads } from '@/db/schema';
import { contactFormSchema } from '@/lib/validations';

/**
 * POST /api/contact
 * Submit contact form
 */
export async function POST(request: NextRequest) {
  try {
    // Parse request body
    const body = await request.json();
    
    // Validate input
    const validatedData = contactFormSchema.parse(body);
    
    // Extract UTM parameters and referer from headers
    const referer = request.headers.get('referer') || '';
    const userAgent = request.headers.get('user-agent') || '';
    
    const url = new URL(referer || request.url);
    const searchParams = url.searchParams;
    
    // Insert into database
    const [lead] = await db.insert(leads).values({
      name: validatedData.name,
      email: validatedData.email,
      phone: validatedData.phone || null,
      company: validatedData.company || null,
      budget: validatedData.budget || null,
      message: validatedData.message || null,
      source: searchParams.get('utm_source') || null,
      medium: searchParams.get('utm_medium') || null,
      campaign: searchParams.get('utm_campaign') || null,
      referrer: referer || null,
      userAgent: userAgent,
      contacted: false,
    }).returning();
    
    // TODO: Send email notification (using Resend, SendGrid, etc.)
    // TODO: Send to CRM (HubSpot, Pipedrive, etc.)
    // TODO: Send WhatsApp notification to team
    
    return NextResponse.json(
      {
        success: true,
        message: 'Recebemos seu contato! Responderemos em até 4 horas úteis.',
        leadId: lead.id,
      },
      { status: 201 }
    );
    
  } catch (error) {
    console.error('Contact form error:', error);
    
    // Validation error
    if (error instanceof Error && error.name === 'ZodError') {
      return NextResponse.json(
        {
          success: false,
          message: 'Dados inválidos. Por favor, verifique os campos.',
          error: error.message,
        },
        { status: 400 }
      );
    }
    
    // Server error
    return NextResponse.json(
      {
        success: false,
        message: 'Erro ao processar. Por favor, tente novamente ou entre em contato via WhatsApp.',
        error: 'Internal server error',
      },
      { status: 500 }
    );
  }
}

/**
 * OPTIONS /api/contact
 * CORS preflight
 */
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    },
  });
}
