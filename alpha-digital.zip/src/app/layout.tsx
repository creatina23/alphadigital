/**
 * Root Layout
 * Global layout wrapper for all pages
 * Includes fonts, metadata, analytics
 */

import type { Metadata } from 'next';
import { Space_Grotesk, JetBrains_Mono } from 'next/font/google';
import { Analytics } from '@vercel/analytics/react';
import { SpeedInsights } from '@vercel/speed-insights/next';
import './globals.css';

/**
 * Font Configurations
 * Using Next.js Font Optimization
 */
const spaceGrotesk = Space_Grotesk({
  subsets: ['latin'],
  variable: '--font-space-grotesk',
  display: 'swap',
  weight: ['300', '400', '500', '600', '700'],
  preload: true,
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-jetbrains-mono',
  display: 'swap',
  weight: ['400', '600'],
  preload: true,
});

/**
 * Metadata Configuration
 * SEO optimization
 */
export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000'),
  
  title: {
    default: 'Alpha Digital | Sites que vendem, não só enfeitam',
    template: '%s | Alpha Digital',
  },
  
  description: '90 dias pra dobrar conversão. Ou você não paga. R$ 8.7 milhões gerados para 23 empresas que tinham tráfego mas não conversão. Apenas 1 vaga em fevereiro.',
  
  keywords: [
    'desenvolvimento web',
    'otimização de conversão',
    'CRO',
    'landing page',
    'agência digital',
    'websites que vendem',
    'design de conversão',
    'performance web',
    'Next.js',
    'desenvolvimento SP',
  ],
  
  authors: [{ name: 'Alpha Digital' }],
  creator: 'Alpha Digital',
  publisher: 'Alpha Digital',
  
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  
  openGraph: {
    type: 'website',
    locale: 'pt_BR',
    url: '/',
    siteName: 'Alpha Digital',
    title: 'Alpha Digital | Sites que vendem, não só enfeitam',
    description: '90 dias pra dobrar conversão. Ou você não paga.',
    images: [
      {
        url: '/og-image.jpg',
        width: 1200,
        height: 630,
        alt: 'Alpha Digital - Sites que vendem',
      },
    ],
  },
  
  twitter: {
    card: 'summary_large_image',
    title: 'Alpha Digital | Sites que vendem, não só enfeitam',
    description: '90 dias pra dobrar conversão. Ou você não paga.',
    images: ['/twitter-image.jpg'],
  },
  
  alternates: {
    canonical: '/',
  },
  
  other: {
    'format-detection': 'telephone=no',
  },
};

/**
 * Viewport Configuration
 */
export const viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  themeColor: '#0A0A0F',
};

/**
 * Root Layout Component
 */
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html 
      lang="pt-BR" 
      className={`${spaceGrotesk.variable} ${jetbrainsMono.variable}`}
      suppressHydrationWarning
    >
      <head>
        {/* Preconnect to external domains */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        
        {/* DNS Prefetch for WhatsApp */}
        <link rel="dns-prefetch" href="https://wa.me" />
      </head>
      
      <body className="antialiased">
        {/* Skip to main content (Accessibility) */}
        <a 
          href="#main-content" 
          className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-50 focus:px-6 focus:py-3 focus:bg-primary focus:text-void focus:rounded-lg focus:font-semibold"
        >
          Pular para o conteúdo principal
        </a>
        
        {/* Main Content */}
        <main id="main-content">
          {children}
        </main>
        
        {/* Analytics */}
        <Analytics />
        <SpeedInsights />
        
        {/* Structured Data (JSON-LD) */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              '@context': 'https://schema.org',
              '@type': 'ProfessionalService',
              name: 'Alpha Digital',
              description: 'Agência digital especializada em sites de alta conversão',
              url: process.env.NEXT_PUBLIC_SITE_URL,
              logo: `${process.env.NEXT_PUBLIC_SITE_URL}/logo.png`,
              image: `${process.env.NEXT_PUBLIC_SITE_URL}/og-image.jpg`,
              telephone: '+55-11-99999-9999',
              email: 'contato@alphadigital.com.br',
              address: {
                '@type': 'PostalAddress',
                addressLocality: 'São Paulo',
                addressRegion: 'SP',
                addressCountry: 'BR',
              },
              geo: {
                '@type': 'GeoCoordinates',
                latitude: -23.561684,
                longitude: -46.655981,
              },
              priceRange: 'R$ 22.000 - R$ 85.000',
              sameAs: [
                'https://linkedin.com/company/alphadigital',
                'https://instagram.com/alphadigital',
              ],
            }),
          }}
        />
      </body>
    </html>
  );
}
