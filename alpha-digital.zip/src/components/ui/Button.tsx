/**
 * Button Component
 * Reusable button with variants and sizes
 */

'use client';

import { ButtonHTMLAttributes, forwardRef } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/lib/utils';

/**
 * Button Variants
 * Using CVA for type-safe variant generation
 */
const buttonVariants = cva(
  // Base styles
  'inline-flex items-center justify-center gap-2 font-semibold rounded-xl transition-all duration-200 disabled:opacity-40 disabled:cursor-not-allowed disabled:pointer-events-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-void',
  {
    variants: {
      variant: {
        primary:
          'bg-gradient-button-primary text-void shadow-md hover:shadow-glow-cyan hover:-translate-y-0.5 active:translate-y-0',
        secondary:
          'bg-transparent border-2 border-primary text-primary hover:bg-primary/10 hover:shadow-glow-cyan hover:-translate-y-0.5',
        ghost:
          'bg-transparent text-text-secondary hover:bg-white/5 hover:text-text-primary',
        whatsapp:
          'bg-gradient-to-r from-[#25D366] to-[#128C7E] text-white shadow-md hover:shadow-[0_0_30px_rgba(37,211,102,0.4)] hover:-translate-y-0.5',
      },
      size: {
        sm: 'px-4 py-2 text-sm min-h-[36px]',
        md: 'px-6 py-3 text-base min-h-[44px]',
        lg: 'px-8 py-4 text-lg min-h-[56px] rounded-2xl',
        xl: 'px-10 py-5 text-xl min-h-[64px] rounded-2xl',
      },
    },
    defaultVariants: {
      variant: 'primary',
      size: 'md',
    },
  }
);

export interface ButtonProps
  extends ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

/**
 * Button Component
 */
const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, ...props }, ref) => {
    return (
      <button
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    );
  }
);

Button.displayName = 'Button';

export { Button, buttonVariants };
