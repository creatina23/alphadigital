/**
 * Process Section
 * Explains the agency's step-by-step methodology
 */

const steps = [
  {
    number: '01',
    title: 'Discovery Call',
    description:
      'Mapeamos seu funil atual, onde os visitantes travam e qual é o real gargalo de conversão. Sem achismo, com dados.',
  },
  {
    number: '02',
    title: 'Diagnóstico & Estratégia',
    description:
      'Entregamos um plano de ação com hipóteses priorizadas por impacto, baseado em CRO e comportamento do usuário.',
  },
  {
    number: '03',
    title: 'Design & Desenvolvimento',
    description:
      'Construímos o site em Next.js com foco em performance, copy orientada a venda e testes A/B desde o primeiro dia.',
  },
  {
    number: '04',
    title: 'Otimização Contínua',
    description:
      'Acompanhamos os números por 90 dias, ajustando o que for preciso até bater a meta de conversão combinada.',
  },
];

export default function Process() {
  return (
    <section id="processo" className="section-padding bg-surface">
      <div className="container-custom">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Como funciona</h2>
          <p className="text-text-secondary max-w-2xl mx-auto">
            Um processo direto, sem enrolação, pensado para gerar resultado mensurável em 90 dias.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step) => (
            <div key={step.number} className="relative p-6 rounded-2xl bg-white/5 border border-white/5">
              <span className="text-4xl font-bold gradient-text">{step.number}</span>
              <h3 className="text-lg font-semibold mt-4 mb-2">{step.title}</h3>
              <p className="text-sm text-text-secondary leading-relaxed">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
