/**
 * Hero Section
 * Main landing section with headline, CTA, and animated visual
 */

'use client';

import { useEffect, useState } from 'react';
import { MessageCircle, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { getWhatsAppLink } from '@/lib/utils';

/**
 * Hero Component
 */
export default function Hero() {
  const [scrollY, setScrollY] = useState(0);
  
  // Parallax effect
  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  const whatsappLink = getWhatsAppLink(
    process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || '',
    process.env.NEXT_PUBLIC_WHATSAPP_MESSAGE || 'Olá! Vim do site.'
  );

  return (
    <section className="relative min-h-screen flex items-center overflow-hidden bg-void">
      {/* Background Mesh Gradient */}
      <div 
        className="absolute inset-0 bg-gradient-hero opacity-60"
        style={{
          transform: `translateY(${scrollY * 0.5}px)`,
        }}
      />
      
      {/* Grid Pattern Overlay */}
      <div className="absolute inset-0 opacity-[0.02]" 
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }}
      />
      
      {/* Content Container */}
      <div className="container-custom relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          
          {/* Left Column: Text Content */}
          <div className="space-y-8">
            
            {/* Scarcity Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-error/10 border border-error/30 text-error text-sm font-semibold animate-fade-up">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-error opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-error"></span>
              </span>
              FEVEREIRO · 1 VAGA RESTANTE
            </div>
            
            {/* Main Headline */}
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight animate-blur-in text-balance">
              <span className="text-text-primary">
                847 pessoas clicaram no seu anúncio ontem.
              </span>
              <br />
              <br />
              <span className="text-text-secondary">
                2 entraram em contato.
              </span>
              <br />
              <br />
              <span className="text-text-tertiary">
                0 fecharam.
              </span>
            </h1>
            
            {/* Subheadline */}
            <div className="space-y-4 text-lg text-text-secondary animate-fade-up" style={{ animationDelay: '200ms' }}>
              <p className="font-bold text-2xl gradient-text">
                R$ 8.7 milhões em vendas.
              </p>
              <p>
                Gerados para 23 empresas que tinham tráfego... mas não conversão.
              </p>
              <p className="text-text-primary font-semibold">
                A diferença?<br />
                Paramos de fazer &ldquo;sites bonitos&rdquo; e começamos a fazer sites que pagam a conta.
              </p>
            </div>
            
            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 animate-fade-up" style={{ animationDelay: '400ms' }}>
              <Button
                variant="whatsapp"
                size="lg"
                className="group"
                onClick={() => window.open(whatsappLink, '_blank')}
              >
                <MessageCircle className="h-5 w-5" />
                Ver Onde Estou Perdendo Vendas
                <TrendingUp className="h-5 w-5 opacity-0 -ml-4 group-hover:opacity-100 group-hover:ml-0 transition-all" />
              </Button>
              
              <div className="text-sm text-text-tertiary text-center sm:text-left">
                Auditoria gratuita · WhatsApp · Resposta em 4h
              </div>
            </div>
            
            {/* Social Proof */}
            <div className="pt-8 border-t border-white/5 animate-fade-up" style={{ animationDelay: '600ms' }}>
              <p className="text-sm text-text-tertiary mb-4">
                Clientes que confiaram:
              </p>
              <div className="flex flex-wrap items-center gap-6 opacity-50 hover:opacity-100 transition-opacity">
                {/* Placeholder for client logos */}
                <div className="h-8 w-24 bg-white/10 rounded"></div>
                <div className="h-8 w-24 bg-white/10 rounded"></div>
                <div className="h-8 w-24 bg-white/10 rounded"></div>
                <div className="h-8 w-24 bg-white/10 rounded"></div>
                <div className="h-8 w-24 bg-white/10 rounded"></div>
              </div>
              <p className="text-xs text-text-tertiary mt-2">
                Varejo · E-commerce · Serviços · Saúde · Educação
              </p>
            </div>
            
          </div>
          
          {/* Right Column: Animated Visual */}
          <div className="relative h-[400px] lg:h-[600px] animate-scale-in" style={{ animationDelay: '300ms' }}>
            
            {/* Dashboard Mockup */}
            <div className="absolute inset-0 glass-strong rounded-2xl p-6 flex flex-col justify-between border border-primary/20 shadow-glow-cyan">
              
              {/* Before State */}
              <div className="space-y-4">
                <div className="text-sm font-mono text-text-tertiary">ANTES</div>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-text-secondary text-sm">Visitantes</span>
                    <span className="font-mono text-2xl text-text-primary">12,430</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-text-secondary text-sm">Leads</span>
                    <span className="font-mono text-2xl text-error">38 (0.3%)</span>
                  </div>
                </div>
              </div>
              
              {/* Arrow Transition */}
              <div className="flex justify-center my-4">
                <div className="h-12 w-0.5 bg-gradient-to-b from-error via-warning to-success animate-pulse"></div>
              </div>
              
              {/* After State */}
              <div className="space-y-4">
                <div className="text-sm font-mono text-text-tertiary">DEPOIS</div>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-text-secondary text-sm">Visitantes</span>
                    <span className="font-mono text-2xl text-text-primary">12,430</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-text-secondary text-sm">Leads</span>
                    <span className="font-mono text-2xl text-success">497 (4.0%)</span>
                  </div>
                </div>
                
                {/* Result Highlight */}
                <div className="pt-4 border-t border-success/20">
                  <div className="text-sm text-text-tertiary">Diferença</div>
                  <div className="text-3xl font-bold gradient-text font-mono mt-1">
                    +R$ 1.2M/ano
                  </div>
                </div>
              </div>
              
            </div>
            
            {/* Glow Effect */}
            <div className="absolute -inset-4 bg-gradient-to-r from-primary/20 to-secondary/20 rounded-3xl blur-3xl -z-10 animate-pulse"></div>
            
          </div>
          
        </div>
      </div>
      
      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/20 rounded-full p-1">
          <div className="w-1.5 h-3 bg-primary rounded-full mx-auto animate-pulse"></div>
        </div>
      </div>
      
    </section>
  );
}
