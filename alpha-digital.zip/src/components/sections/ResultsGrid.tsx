/**
 * ResultsGrid Section
 * Grid of aggregate results / social proof metrics
 */

const results = [
  { value: 'R$ 8.7M', label: 'Gerados em vendas para clientes' },
  { value: '23', label: 'Empresas atendidas' },
  { value: '+94%', label: 'Conversão média de melhoria' },
  { value: '90 dias', label: 'Prazo médio de resultado' },
];

export default function ResultsGrid() {
  return (
    <section className="section-padding bg-surface">
      <div className="container-custom">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Resultados que falam por si</h2>
          <p className="text-text-secondary max-w-2xl mx-auto">
            Números consolidados dos projetos que entregamos nos últimos anos.
          </p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {results.map((r) => (
            <div
              key={r.label}
              className="text-center p-6 rounded-2xl bg-white/5 border border-white/5"
            >
              <p className="text-3xl md:text-4xl font-bold gradient-text mb-2">{r.value}</p>
              <p className="text-sm text-text-secondary">{r.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
