/**
 * CaseHero Section
 * Featured case study highlight
 */

export default function CaseHero() {
  return (
    <section id="cases" className="section-padding bg-void">
      <div className="container-custom">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <span className="text-sm font-semibold text-primary uppercase tracking-wide">
              Case em destaque
            </span>
            <h2 className="text-3xl md:text-4xl font-bold mt-3 mb-6">
              Como reestruturamos um funil parado e destravamos a conversão
            </h2>
            <p className="text-text-secondary leading-relaxed mb-6">
              Um e-commerce com bom volume de tráfego pago, mas taxa de conversão
              travada. Reescrevemos a jornada do usuário, o copy e a performance
              técnica do zero — sem depender de mais investimento em mídia.
            </p>
            <div className="flex flex-wrap gap-6">
              <div>
                <p className="text-2xl font-bold gradient-text">+118%</p>
                <p className="text-xs text-text-tertiary">conversão em 90 dias</p>
              </div>
              <div>
                <p className="text-2xl font-bold gradient-text">-42%</p>
                <p className="text-xs text-text-tertiary">custo por aquisição</p>
              </div>
              <div>
                <p className="text-2xl font-bold gradient-text">0.9s</p>
                <p className="text-xs text-text-tertiary">tempo de carregamento</p>
              </div>
            </div>
          </div>

          <div className="rounded-2xl border border-white/5 bg-white/5 aspect-video flex items-center justify-center">
            <span className="text-text-tertiary text-sm">
              [ Screenshot / vídeo do case aqui ]
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
