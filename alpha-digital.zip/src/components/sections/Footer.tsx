export default function Footer() {
  return (
    <footer className="bg-void border-t border-white/5 py-12">
      <div className="container-custom">
        <div className="text-center">
          <p className="text-sm text-text-tertiary">
            © 2026 Alpha Digital. Todos os direitos reservados.
          </p>
          <p className="text-xs text-text-quaternary mt-2">
            Este site carregou em 0.87s. 94% mais rápido que a média da web.
          </p>
        </div>
      </div>
    </footer>
  );
}
