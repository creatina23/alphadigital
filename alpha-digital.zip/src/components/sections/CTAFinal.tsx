/**
 * CTAFinal Section
 * Last call-to-action before the footer
 */

'use client';

import { MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { getWhatsAppLink } from '@/lib/utils';

export default function CTAFinal() {
  const whatsappLink = getWhatsAppLink(
    process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || '',
    'Olá! Quero agendar uma Discovery Call.'
  );

  return (
    <section className="section-padding bg-surface">
      <div className="container-custom text-center max-w-2xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold mb-4">
          Apenas 1 vaga disponível este mês
        </h2>
        <p className="text-text-secondary mb-8">
          Agende uma Discovery Call gratuita e descubra onde seu funil está
          perdendo conversão — e o que fazer para reverter isso.
        </p>
        <Button
          size="xl"
          variant="whatsapp"
          onClick={() => window.open(whatsappLink, '_blank')}
        >
          <MessageCircle className="h-5 w-5" />
          Agendar Discovery Call
        </Button>
      </div>
    </section>
  );
}
