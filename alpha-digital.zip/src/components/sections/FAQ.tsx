/**
 * FAQ Section
 * Common questions to reduce objection before the CTA
 */

'use client';

import { useState } from 'react';
import { ChevronDown } from 'lucide-react';

const faqs = [
  {
    question: 'Quanto tempo leva para ver resultado?',
    answer:
      'Trabalhamos com ciclos de 90 dias. Os primeiros ajustes de conversão costumam aparecer já nas primeiras semanas, mas o compromisso de resultado é medido no ciclo completo.',
  },
  {
    question: 'O que está incluso no projeto?',
    answer:
      'Discovery, estratégia de CRO, design, desenvolvimento do site em Next.js, integração com analytics e acompanhamento de otimização durante os 90 dias.',
  },
  {
    question: 'Vocês atendem qualquer segmento?',
    answer:
      'Priorizamos negócios que já têm tráfego (pago ou orgânico) mas não estão convertendo na medida esperada. Se esse é o seu caso, provavelmente conseguimos ajudar.',
  },
  {
    question: 'Como funciona a garantia "ou você não paga"?',
    answer:
      'As condições específicas da garantia são definidas na Discovery Call, de acordo com o seu cenário atual de tráfego e conversão.',
  },
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section id="faq" className="section-padding bg-void">
      <div className="container-custom max-w-3xl">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
          Perguntas frequentes
        </h2>

        <div className="space-y-3">
          {faqs.map((faq, index) => {
            const isOpen = openIndex === index;
            return (
              <div
                key={faq.question}
                className="rounded-xl border border-white/5 bg-white/5 overflow-hidden"
              >
                <button
                  className="w-full flex items-center justify-between px-6 py-4 text-left"
                  onClick={() => setOpenIndex(isOpen ? null : index)}
                  aria-expanded={isOpen}
                >
                  <span className="font-semibold">{faq.question}</span>
                  <ChevronDown
                    className={`h-5 w-5 shrink-0 transition-transform ${isOpen ? 'rotate-180' : ''}`}
                  />
                </button>
                {isOpen && (
                  <div className="px-6 pb-4 text-sm text-text-secondary leading-relaxed">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
