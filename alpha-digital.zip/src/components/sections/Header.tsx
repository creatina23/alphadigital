/**
 * Header Component
 * Fixed navigation header
 */

'use client';

import { MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { getWhatsAppLink } from '@/lib/utils';

export default function Header() {
  const whatsappLink = getWhatsAppLink(
    process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || '',
    'Olá! Quero agendar uma Discovery Call.'
  );

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-void/80 backdrop-blur-lg border-b border-white/5">
      <div className="container-custom">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="text-xl font-bold gradient-text">
            Alpha Digital
          </div>

          {/* Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <a href="#cases" className="text-sm text-text-secondary hover:text-text-primary transition">
              Cases
            </a>
            <a href="#processo" className="text-sm text-text-secondary hover:text-text-primary transition">
              Processo
            </a>
            <a href="#faq" className="text-sm text-text-secondary hover:text-text-primary transition">
              FAQ
            </a>
          </nav>

          {/* CTA */}
          <Button
            size="sm"
            onClick={() => window.open(whatsappLink, '_blank')}
          >
            <MessageCircle className="h-4 w-4" />
            WhatsApp
          </Button>
        </div>
      </div>
    </header>
  );
}
