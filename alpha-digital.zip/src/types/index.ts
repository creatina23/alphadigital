/**
 * Global Type Definitions
 * Shared TypeScript types and interfaces
 */

/**
 * Case Study Data Structure
 */
export interface CaseStudy {
  id: string;
  slug: string;
  category: string;
  industry: string;
  client: {
    name: string;
    logo?: string;
    location: string;
    revenue?: string;
  };
  problem: {
    headline: string;
    description: string;
    metrics: {
      label: string;
      value: string;
    }[];
    screenshot?: string;
  };
  solution: {
    headline: string;
    changes: {
      category: string;
      before: string;
      after: string;
    }[];
    screenshot?: string;
  };
  results: {
    headline: string;
    metrics: {
      label: string;
      before: string;
      after: string;
      change: string;
    }[];
    roi?: {
      investment: number;
      return: number;
      percentage: number;
    };
  };
  testimonial?: {
    quote: string;
    author: string;
    role: string;
    avatar?: string;
    linkedin?: string;
    videoUrl?: string;
  };
}

/**
 * FAQ Item
 */
export interface FAQItem {
  question: string;
  answer: string;
  icon?: string;
}

/**
 * Process Step
 */
export interface ProcessStep {
  number: number;
  title: string;
  duration: string;
  cost?: string;
  description: string;
  deliverables: string[];
  tooltip?: string;
}

/**
 * Client Logo
 */
export interface ClientLogo {
  name: string;
  logo: string;
  url?: string;
}

/**
 * Result Card (for grid section)
 */
export interface ResultCard {
  id: string;
  category: string;
  industry: string;
  problem: string;
  metrics: {
    label: string;
    value: string;
  }[];
  caseLink?: string;
}

/**
 * Newsletter Subscription Response
 */
export interface NewsletterResponse {
  success: boolean;
  message: string;
  error?: string;
}

/**
 * Contact Form Response
 */
export interface ContactResponse {
  success: boolean;
  message: string;
  error?: string;
}

/**
 * Analytics Event
 */
export interface AnalyticsEvent {
  event: string;
  category?: string;
  label?: string;
  value?: number;
  [key: string]: any;
}
