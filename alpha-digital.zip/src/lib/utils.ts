/**
 * Utility Functions
 * Shared helper functions used across the application
 */

import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

/**
 * Merge Tailwind CSS classes with proper precedence
 * Combines clsx for conditional classes and tailwind-merge for deduplication
 * 
 * @param inputs - Class values to merge
 * @returns Merged class string
 * 
 * @example
 * cn('px-4 py-2', isActive && 'bg-primary', className)
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Format number with thousand separators
 * 
 * @param value - Number to format
 * @param locale - Locale for formatting (default: pt-BR)
 * @returns Formatted number string
 * 
 * @example
 * formatNumber(1234567) // "1.234.567"
 */
export function formatNumber(value: number, locale: string = 'pt-BR'): string {
  return new Intl.NumberFormat(locale).format(value);
}

/**
 * Format currency in Brazilian Real
 * 
 * @param value - Amount to format
 * @param showSymbol - Whether to show R$ symbol
 * @returns Formatted currency string
 * 
 * @example
 * formatCurrency(35000) // "R$ 35.000"
 */
export function formatCurrency(value: number, showSymbol: boolean = true): string {
  const formatted = new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);

  return showSymbol ? formatted : formatted.replace('R$', '').trim();
}

/**
 * Generate WhatsApp link with pre-filled message
 * 
 * @param phone - Phone number (digits only)
 * @param message - Pre-filled message
 * @returns WhatsApp web URL
 * 
 * @example
 * getWhatsAppLink('5511999999999', 'Olá!')
 */
export function getWhatsAppLink(phone: string, message: string): string {
  const encodedMessage = encodeURIComponent(message);
  return `https://wa.me/${phone}?text=${encodedMessage}`;
}

/**
 * Debounce function execution
 * 
 * @param func - Function to debounce
 * @param wait - Wait time in milliseconds
 * @returns Debounced function
 */
export function debounce<T extends (...args: any[]) => any>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout;
  
  return function executedFunction(...args: Parameters<T>) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

/**
 * Generate unique session ID for analytics
 * Uses browser fingerprinting (simple version)
 * 
 * @returns Session ID string
 */
export function generateSessionId(): string {
  const timestamp = Date.now().toString(36);
  const randomStr = Math.random().toString(36).substring(2, 9);
  return `${timestamp}-${randomStr}`;
}

/**
 * Get device type based on window width
 * 
 * @param width - Window width
 * @returns Device type
 */
export function getDeviceType(width: number): 'mobile' | 'tablet' | 'desktop' {
  if (width < 768) return 'mobile';
  if (width < 1024) return 'tablet';
  return 'desktop';
}

/**
 * Extract UTM parameters from URL
 * 
 * @param url - URL to parse
 * @returns UTM parameters object
 */
export function extractUTMParams(url: string): {
  source?: string;
  medium?: string;
  campaign?: string;
} {
  const urlObj = new URL(url);
  const params = new URLSearchParams(urlObj.search);
  
  return {
    source: params.get('utm_source') || undefined,
    medium: params.get('utm_medium') || undefined,
    campaign: params.get('utm_campaign') || undefined,
  };
}

/**
 * Animate number counter (count-up effect)
 * 
 * @param element - DOM element to update
 * @param end - End value
 * @param duration - Animation duration in ms
 * @param start - Start value (default: 0)
 */
export function animateCounter(
  element: HTMLElement,
  end: number,
  duration: number = 1200,
  start: number = 0
): void {
  const range = end - start;
  const increment = range / (duration / 16); // 60fps
  let current = start;
  
  const timer = setInterval(() => {
    current += increment;
    
    if (current >= end) {
      element.textContent = formatNumber(Math.floor(end));
      clearInterval(timer);
    } else {
      element.textContent = formatNumber(Math.floor(current));
    }
  }, 16);
}

/**
 * Check if element is in viewport
 * 
 * @param element - DOM element to check
 * @param offset - Offset from viewport edge (default: 0)
 * @returns Whether element is in viewport
 */
export function isInViewport(element: HTMLElement, offset: number = 0): boolean {
  const rect = element.getBoundingClientRect();
  
  return (
    rect.top >= -offset &&
    rect.left >= -offset &&
    rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) + offset &&
    rect.right <= (window.innerWidth || document.documentElement.clientWidth) + offset
  );
}
