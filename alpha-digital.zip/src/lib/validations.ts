/**
 * Form Validation Schemas
 * Zod schemas for type-safe form validation
 * 
 * @see https://zod.dev/
 */

import { z } from 'zod';

/**
 * Contact Form Schema
 * Validates discovery call request submissions
 */
export const contactFormSchema = z.object({
  name: z
    .string()
    .min(2, 'Nome deve ter no mínimo 2 caracteres')
    .max(100, 'Nome muito longo')
    .regex(/^[a-zA-ZÀ-ÿ\s]+$/, 'Nome deve conter apenas letras'),
  
  email: z
    .string()
    .email('Email inválido')
    .toLowerCase()
    .refine(
      (email) => !email.endsWith('@example.com'),
      'Por favor, use um email real'
    ),
  
  phone: z
    .string()
    .min(10, 'Telefone inválido')
    .max(15, 'Telefone inválido')
    .regex(/^[0-9+\s()-]+$/, 'Telefone deve conter apenas números')
    .optional()
    .or(z.literal('')),
  
  company: z
    .string()
    .min(2, 'Nome da empresa muito curto')
    .max(100, 'Nome da empresa muito longo')
    .optional()
    .or(z.literal('')),
  
  budget: z
    .enum(['22k-35k', '35k-85k', '85k+', 'not-sure'])
    .optional(),
  
  message: z
    .string()
    .max(1000, 'Mensagem muito longa (máximo 1000 caracteres)')
    .optional()
    .or(z.literal('')),
});

/**
 * Newsletter Subscription Schema
 * Validates email-only newsletter signups
 */
export const newsletterSchema = z.object({
  email: z
    .string()
    .email('Email inválido')
    .toLowerCase()
    .refine(
      (email) => !email.endsWith('@example.com'),
      'Por favor, use um email real'
    ),
});

/**
 * Type inference from schemas
 */
export type ContactFormData = z.infer<typeof contactFormSchema>;
export type NewsletterFormData = z.infer<typeof newsletterSchema>;
