/**
 * Database Connection
 * Singleton pattern for Drizzle ORM client
 * 
 * @see https://orm.drizzle.team/docs/get-started-postgresql
 */

import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import * as schema from './schema';

/**
 * Environment variable validation
 */
if (!process.env.DATABASE_URL) {
  throw new Error('DATABASE_URL environment variable is not set');
}

/**
 * PostgreSQL connection
 * Uses connection pooling for optimal performance
 */
const client = postgres(process.env.DATABASE_URL, {
  max: 10, // Maximum connections in pool
  idle_timeout: 20, // Close idle connections after 20s
  connect_timeout: 10, // Connection timeout
});

/**
 * Drizzle ORM instance
 * Singleton exported for use throughout the application
 */
export const db = drizzle(client, { schema });

/**
 * Export schema for type inference
 */
export { schema };
