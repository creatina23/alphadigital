/**
 * Database Schema
 * Drizzle ORM schema definitions for PostgreSQL
 * 
 * Tables:
 * - leads: Contact form submissions
 * - newsletter: Email subscribers
 * - pageViews: Anonymous analytics
 */

import { pgTable, serial, text, timestamp, integer, boolean } from 'drizzle-orm/pg-core';

/**
 * Leads Table
 * Stores all contact form submissions and discovery call requests
 */
export const leads = pgTable('leads', {
  id: serial('id').primaryKey(),
  
  // Contact information
  name: text('name').notNull(),
  email: text('email').notNull(),
  phone: text('phone'),
  company: text('company'),
  
  // Lead qualification
  budget: text('budget'), // "22k-35k", "35k-85k", "85k+"
  message: text('message'),
  
  // Tracking
  source: text('source'), // UTM source
  medium: text('medium'), // UTM medium
  campaign: text('campaign'), // UTM campaign
  referrer: text('referrer'), // HTTP referrer
  
  // Metadata
  createdAt: timestamp('created_at').defaultNow().notNull(),
  contacted: boolean('contacted').default(false).notNull(),
  contactedAt: timestamp('contacted_at'),
  
  // User agent for device detection
  userAgent: text('user_agent'),
});

/**
 * Newsletter Table
 * Email subscribers for weekly content
 */
export const newsletter = pgTable('newsletter', {
  id: serial('id').primaryKey(),
  
  email: text('email').notNull().unique(),
  
  // Source tracking
  source: text('source'), // "homepage", "exit-intent", "footer"
  
  // Status
  active: boolean('active').default(true).notNull(),
  subscribedAt: timestamp('subscribed_at').defaultNow().notNull(),
  unsubscribedAt: timestamp('unsubscribed_at'),
});

/**
 * Page Views Table
 * Anonymous analytics for scroll depth and engagement
 */
export const pageViews = pgTable('page_views', {
  id: serial('id').primaryKey(),
  
  // Session identification (anonymous)
  sessionId: text('session_id').notNull(),
  
  // Engagement metrics
  scrollDepth: integer('scroll_depth'), // % scrolled (0-100)
  timeOnPage: integer('time_on_page'), // seconds
  
  // Device info
  deviceType: text('device_type'), // "mobile", "tablet", "desktop"
  
  // Timestamp
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

/**
 * TypeScript types exported from schema
 */
export type Lead = typeof leads.$inferSelect;
export type NewLead = typeof leads.$inferInsert;

export type NewsletterSubscriber = typeof newsletter.$inferSelect;
export type NewNewsletterSubscriber = typeof newsletter.$inferInsert;

export type PageView = typeof pageViews.$inferSelect;
export type NewPageView = typeof pageViews.$inferInsert;
