import type { Config } from 'tailwindcss';

/**
 * Tailwind CSS Configuration
 * Custom design system implementation
 * 
 * @see https://tailwindcss.com/docs/configuration
 */
const config: Config = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      /**
       * Custom Color Palette
       * Based on Design System defined in PRD
       */
      colors: {
        // Foundation (Dark theme)
        void: '#0A0A0F',
        surface: {
          DEFAULT: '#15151F',
          elevated: '#1E1E2E',
          overlay: '#27273A',
        },
        
        // Text colors
        text: {
          primary: '#FAFAFA',
          secondary: '#A8A8B8',
          tertiary: '#6B6B7E',
          quaternary: '#3D3D4D',
        },

        // Accent colors
        primary: {
          DEFAULT: '#00F0FF',
          hover: '#00D8E6',
          light: '#4DF4FF',
          dark: '#00BCC7',
        },
        secondary: {
          DEFAULT: '#FF006E',
          hover: '#E6005C',
          light: '#FF4D9B',
        },
        tertiary: {
          DEFAULT: '#9D4EFF',
          hover: '#8A3FE6',
        },

        // Performance colors
        perf: {
          extreme: '#00FF94',
          excellent: '#00F0FF',
          good: '#FFD600',
          poor: '#FF006E',
        },

        // Semantic colors
        success: '#00FF94',
        warning: '#FFD600',
        error: '#FF006E',
        info: '#00F0FF',
      },

      /**
       * Typography
       * Space Grotesk Variable + JetBrains Mono
       */
      fontFamily: {
        display: ['var(--font-space-grotesk)', 'system-ui', 'sans-serif'],
        body: ['var(--font-space-grotesk)', 'system-ui', 'sans-serif'],
        mono: ['var(--font-jetbrains-mono)', 'ui-monospace', 'monospace'],
      },

      /**
       * Font Sizes
       * Modular scale (1.250 - Major Third)
       */
      fontSize: {
        xs: ['0.75rem', { lineHeight: '1.5' }],      // 12px
        sm: ['0.875rem', { lineHeight: '1.5' }],     // 14px
        base: ['1rem', { lineHeight: '1.5' }],       // 16px
        md: ['1.125rem', { lineHeight: '1.5' }],     // 18px
        lg: ['1.25rem', { lineHeight: '1.3' }],      // 20px
        xl: ['1.563rem', { lineHeight: '1.3' }],     // 25px
        '2xl': ['1.953rem', { lineHeight: '1.15' }], // 31.25px
        '3xl': ['2.441rem', { lineHeight: '1.15' }], // 39px
        '4xl': ['3.052rem', { lineHeight: '1.15' }], // 48.8px
        '5xl': ['3.815rem', { lineHeight: '1.1' }],  // 61px
        '6xl': ['4.768rem', { lineHeight: '1.1' }],  // 76.3px
      },

      /**
       * Spacing Scale
       * 8px base system
       */
      spacing: {
        '0': '0',
        '1': '0.25rem',  // 4px
        '2': '0.5rem',   // 8px
        '3': '0.75rem',  // 12px
        '4': '1rem',     // 16px
        '5': '1.5rem',   // 24px
        '6': '2rem',     // 32px
        '7': '2.5rem',   // 40px
        '8': '3rem',     // 48px
        '9': '4rem',     // 64px
        '10': '5rem',    // 80px
        '11': '6rem',    // 96px
        '12': '8rem',    // 128px
        '13': '10rem',   // 160px
        '14': '12rem',   // 192px
        '15': '16rem',   // 256px
      },

      /**
       * Border Radius
       */
      borderRadius: {
        sm: '8px',
        DEFAULT: '12px',
        md: '12px',
        lg: '16px',
        xl: '24px',
        '2xl': '32px',
        full: '9999px',
      },

      /**
       * Box Shadows
       * Multi-layer elevation system
       */
      boxShadow: {
        xs: '0 1px 2px rgba(0, 0, 0, 0.3)',
        sm: '0 2px 4px rgba(0, 0, 0, 0.2), 0 1px 2px rgba(0, 0, 0, 0.3)',
        DEFAULT: '0 4px 8px rgba(0, 0, 0, 0.2), 0 2px 4px rgba(0, 0, 0, 0.3)',
        md: '0 4px 8px rgba(0, 0, 0, 0.2), 0 2px 4px rgba(0, 0, 0, 0.3)',
        lg: '0 8px 16px rgba(0, 0, 0, 0.25), 0 4px 8px rgba(0, 0, 0, 0.3)',
        xl: '0 16px 32px rgba(0, 0, 0, 0.3), 0 8px 16px rgba(0, 0, 0, 0.35)',
        '2xl': '0 24px 48px rgba(0, 0, 0, 0.4), 0 12px 24px rgba(0, 0, 0, 0.4)',
        'glow-cyan': '0 0 20px rgba(0, 240, 255, 0.3), 0 0 40px rgba(0, 240, 255, 0.15), 0 8px 16px rgba(0, 0, 0, 0.3)',
        'glow-magenta': '0 0 20px rgba(255, 0, 110, 0.3), 0 0 40px rgba(255, 0, 110, 0.15), 0 8px 16px rgba(0, 0, 0, 0.3)',
        'glow-purple': '0 0 20px rgba(157, 78, 255, 0.3), 0 0 40px rgba(157, 78, 255, 0.15), 0 8px 16px rgba(0, 0, 0, 0.3)',
        inner: 'inset 0 2px 4px rgba(0, 0, 0, 0.3)',
        'inner-strong': 'inset 0 4px 8px rgba(0, 0, 0, 0.4)',
      },

      /**
       * Animations
       * Custom timing functions and durations
       */
      transitionTimingFunction: {
        'out-expo': 'cubic-bezier(0.16, 1, 0.3, 1)',
        'out-back': 'cubic-bezier(0.34, 1.56, 0.64, 1)',
        'spring': 'cubic-bezier(0.68, -0.55, 0.265, 1.55)',
      },
      
      transitionDuration: {
        instant: '100ms',
        fast: '200ms',
        normal: '300ms',
        slow: '500ms',
        slower: '800ms',
      },

      /**
       * Animation Keyframes
       */
      keyframes: {
        'fade-up': {
          '0%': { opacity: '0', transform: 'translateY(40px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'fade-in': {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        'scale-in': {
          '0%': { opacity: '0', transform: 'scale(0.9)' },
          '100%': { opacity: '1', transform: 'scale(1)' },
        },
        'blur-in': {
          '0%': { opacity: '0', filter: 'blur(10px)', transform: 'translateY(20px)' },
          '100%': { opacity: '1', filter: 'blur(0)', transform: 'translateY(0)' },
        },
        'shimmer': {
          '0%': { transform: 'translateX(-100%)' },
          '100%': { transform: 'translateX(100%)' },
        },
        'skeleton-loading': {
          '0%': { backgroundPosition: '200% 0' },
          '100%': { backgroundPosition: '-200% 0' },
        },
        'spin': {
          '0%': { transform: 'rotate(0deg)' },
          '100%': { transform: 'rotate(360deg)' },
        },
        'rotate': {
          '0%': { transform: 'rotate(0deg)' },
          '100%': { transform: 'rotate(360deg)' },
        },
        'pulse-number': {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0.8' },
        },
      },

      animation: {
        'fade-up': 'fade-up 0.5s cubic-bezier(0.16, 1, 0.3, 1)',
        'fade-in': 'fade-in 0.3s ease-in-out',
        'scale-in': 'scale-in 0.3s cubic-bezier(0.34, 1.56, 0.64, 1)',
        'blur-in': 'blur-in 0.5s cubic-bezier(0.16, 1, 0.3, 1)',
        'shimmer': 'shimmer 2s infinite',
        'skeleton': 'skeleton-loading 1.5s ease-in-out infinite',
        'spin': 'spin 0.8s linear infinite',
        'rotate-slow': 'rotate 20s linear infinite',
        'pulse-number': 'pulse-number 0.2s ease-in-out',
      },

      /**
       * Background Images (Gradients)
       */
      backgroundImage: {
        'gradient-hero': 'radial-gradient(at 20% 30%, rgba(0, 240, 255, 0.2) 0%, transparent 50%), radial-gradient(at 80% 70%, rgba(255, 0, 110, 0.2) 0%, transparent 50%), radial-gradient(at 40% 80%, rgba(157, 78, 255, 0.2) 0%, transparent 50%), linear-gradient(180deg, #0A0A0F 0%, #15151F 100%)',
        'gradient-card': 'radial-gradient(at 0% 0%, rgba(0, 240, 255, 0.08) 0%, transparent 70%), linear-gradient(135deg, #1E1E2E 0%, #15151F 100%)',
        'gradient-button-primary': 'linear-gradient(135deg, #00F0FF 0%, #00BCC7 100%)',
        'gradient-button-secondary': 'linear-gradient(135deg, #FF006E 0%, #E6005C 100%)',
        'gradient-performance': 'linear-gradient(90deg, #FF006E 0%, #FFD600 25%, #00F0FF 50%, #00FF94 100%)',
      },

      /**
       * Backdrop Blur
       */
      backdropBlur: {
        xs: '2px',
        sm: '4px',
        DEFAULT: '8px',
        md: '12px',
        lg: '16px',
        xl: '24px',
        '2xl': '40px',
      },

      /**
       * Container
       */
      container: {
        center: true,
        padding: {
          DEFAULT: '1rem',
          sm: '1rem',
          md: '2rem',
          lg: '3rem',
          xl: '3rem',
          '2xl': '3rem',
        },
        screens: {
          sm: '640px',
          md: '768px',
          lg: '1024px',
          xl: '1280px',
          '2xl': '1440px',
        },
      },
    },
  },
  plugins: [],
};

export default config;
