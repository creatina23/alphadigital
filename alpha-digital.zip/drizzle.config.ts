import type { Config } from 'drizzle-kit';

/**
 * Drizzle Kit Configuration
 * Database migration and introspection tool
 * 
 * @see https://orm.drizzle.team/kit-docs/config-reference
 */
export default {
  schema: './src/db/schema.ts',
  out: './drizzle',
  dialect: 'postgresql',
  dbCredentials: {
    url: process.env.DATABASE_URL!,
  },
  verbose: true,
  strict: true,
} satisfies Config;
