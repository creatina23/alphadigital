# 🚀 Guia Completo de Instalação — Alpha Digital

## Pré-requisitos

✅ **Node.js** 18.17.0+ ([Download](https://nodejs.org/))  
✅ **PostgreSQL** 14+ ([Download](https://www.postgresql.org/download/))  
✅ **Git** ([Download](https://git-scm.com/))  

---

## Passo 1: Instalar Dependências

```bash
npm install
```

**Isso instalará:**
- Next.js 15.0.3
- React 19
- TypeScript
- Tailwind CSS
- Drizzle ORM
- Framer Motion
- Lucide React
- E todas as outras dependências

---

## Passo 2: Configurar PostgreSQL

### Opção A: PostgreSQL Local

```bash
# Criar database
createdb app_db

# Ou via psql
psql -U postgres
CREATE DATABASE app_db;
\q
```

### Opção B: PostgreSQL Cloud (Recomendado)

**Neon.tech** (Grátis):
1. Acesse [neon.tech](https://neon.tech)
2. Crie conta gratuita
3. Crie novo projeto
4. Copie a `DATABASE_URL`

**Supabase** (Grátis):
1. Acesse [supabase.com](https://supabase.com)
2. Crie projeto
3. Settings → Database → Connection String
4. Copie URL (modo "Transaction")

---

## Passo 3: Variáveis de Ambiente

Edite `.env.local`:

```env
# Database (substitua com sua URL)
DATABASE_URL=postgresql://user:password@host:5432/database

# Site
NEXT_PUBLIC_SITE_URL=http://localhost:3000
NEXT_PUBLIC_SITE_NAME=Alpha Digital

# WhatsApp
NEXT_PUBLIC_WHATSAPP_NUMBER=5511999999999
NEXT_PUBLIC_WHATSAPP_MESSAGE=Olá! Vim do site e quero agendar uma Discovery Call.
```

---

## Passo 4: Inicializar Database

```bash
# Aplicar schema ao database
npm run db:push
```

**Você verá:**
```
✓ Applying migrations...
✓ Done!
```

**Para ver o database visualmente:**
```bash
npm run db:studio
```

Abre em `https://local.drizzle.studio`

---

## Passo 5: Iniciar Desenvolvimento

```bash
npm run dev
```

**Acesse:** [http://localhost:3000](http://localhost:3000)

---

## ✅ Verificação

### 1. Homepage Carrega?
- Abra `http://localhost:3000`
- Deve ver Hero section com headline animada

### 2. Database Conectado?
```bash
curl http://localhost:3000/api/health
```

**Resposta esperada:**
```json
{
  "status": "ok",
  "database": "connected",
  "timestamp": "..."
}
```

### 3. WhatsApp Link Funciona?
- Clique no botão verde "Ver Onde Estou Perdendo Vendas"
- Deve abrir WhatsApp Web com mensagem pré-preenchida

---

## 🐛 Troubleshooting

### Erro: "Cannot find module"

```bash
# Limpar e reinstalar
rm -rf node_modules package-lock.json
npm install
```

### Erro: "Database connection failed"

```bash
# Verificar se PostgreSQL está rodando
psql -U postgres -c "SELECT 1"

# Testar conexão
psql postgresql://user:pass@host:5432/database
```

### Erro: "Port 3000 already in use"

```bash
# Matar processo na porta 3000
npx kill-port 3000

# Ou usar outra porta
PORT=3001 npm run dev
```

### Erro TypeScript

```bash
# Verificar tipos
npm run typecheck

# Se houver erros, limpar cache
rm -rf .next
npm run dev
```

---

## 📦 Build de Produção

### 1. Build

```bash
npm run build
```

### 2. Testar Produção Localmente

```bash
npm run start
```

### 3. Verificar Performance

```bash
# Instalar Lighthouse CLI
npm i -g lighthouse

# Rodar audit
lighthouse http://localhost:3000 --view
```

**Targets:**
- Performance: 95+
- Accessibility: 100
- Best Practices: 100
- SEO: 100

---

## 🚀 Deploy

### Vercel (Recomendado)

```bash
# Instalar Vercel CLI
npm i -g vercel

# Deploy
vercel
```

**Configurar:**
1. Adicionar variáveis de ambiente no dashboard
2. Conectar database (Neon, Supabase, etc)
3. Deploy automático a cada push no GitHub

### Outras Plataformas

**Netlify:**
```bash
netlify deploy --prod
```

**Railway:**
```bash
railway up
```

---

## 📊 Monitoramento Pós-Deploy

### 1. Vercel Analytics
- Automático se deployer na Vercel
- Dashboard: `https://vercel.com/[seu-projeto]/analytics`

### 2. Google Analytics

Adicione em `.env.local`:
```env
NEXT_PUBLIC_GA_ID=G-XXXXXXXXXX
```

### 3. Logs de Erro

```bash
# Ver logs em tempo real (Vercel)
vercel logs --follow
```

---

## 🔧 Manutenção

### Atualizar Dependências

```bash
# Verificar atualizações
npm outdated

# Atualizar
npm update

# Major updates (cuidado!)
npx npm-check-updates -u
npm install
```

### Backup Database

```bash
# PostgreSQL dump
pg_dump -U postgres app_db > backup.sql

# Restore
psql -U postgres app_db < backup.sql
```

---

## 📞 Suporte

**Problemas?**
- Email: contato@alphadigital.com.br
- WhatsApp: +55 11 99999-9999

**Documentação:**
- Next.js: [nextjs.org/docs](https://nextjs.org/docs)
- Drizzle: [orm.drizzle.team](https://orm.drizzle.team)
- Tailwind: [tailwindcss.com/docs](https://tailwindcss.com/docs)

---

**Boa sorte! 🚀**
